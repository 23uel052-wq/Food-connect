import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  User, 
  Building2, 
  ChevronRight,
  Bell,
  LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatDistanceToNow, isAfter, addMinutes, differenceInSeconds } from 'date-fns';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// --- Utility ---
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---
type UserRole = 'donor' | 'ngo';

interface FoodPost {
  id: string;
  donorId: string;
  donorName: string;
  foodType: string;
  quantity: string;
  location: string;
  status: 'available' | 'accepted' | 'collected';
  createdAt: number;
}

interface Collection {
  id: string;
  postId: string;
  ngoId: string;
  ngoName: string;
  estimatedPickupTime: number; // in minutes
  pickupDeadline: number; // timestamp
  status: 'pending' | 'collected';
  confirmedAt: number;
}

// --- Mock Data & Persistence ---
// Since we don't have a real Firebase setup in this sandbox without user keys,
// we will use a robust local state that mimics Firestore behavior.
const STORAGE_KEY = 'food_connect_data';

const getInitialData = () => {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) return JSON.parse(saved);
  return {
    posts: [],
    collections: [],
    notifications: []
  };
};

// --- Components ---

const CountdownTimer = ({ deadline, onExpire }: { deadline: number, onExpire?: () => void }) => {
  const [timeLeft, setTimeLeft] = useState(differenceInSeconds(deadline, Date.now()));

  useEffect(() => {
    const timer = setInterval(() => {
      const diff = differenceInSeconds(deadline, Date.now());
      setTimeLeft(diff);
      if (diff <= 0) {
        clearInterval(timer);
        onExpire?.();
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [deadline, onExpire]);

  if (timeLeft <= 0) return <span className="text-red-500 font-bold">EXPIRED</span>;

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="flex items-center gap-1 font-mono text-lg font-bold">
      <Clock className="w-4 h-4 text-emerald-500" />
      <span className={cn(timeLeft < 300 ? "text-red-500 animate-pulse" : "text-emerald-600")}>
        {minutes}:{seconds.toString().padStart(2, '0')}
      </span>
    </div>
  );
};

export default function App() {
  const [role, setRole] = useState<UserRole | null>(null);
  const [data, setData] = useState(getInitialData());
  const [showPostModal, setShowPostModal] = useState(false);
  const [showAcceptModal, setShowAcceptModal] = useState<FoodPost | null>(null);
  const [notifications, setNotifications] = useState<string[]>([]);

  // Persistence
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data]);

  const addNotification = (msg: string) => {
    setNotifications(prev => [msg, ...prev].slice(0, 5));
    // In a real app, this would be FCM
    console.log("Push Notification:", msg);
  };

  // --- Handlers ---
  const handlePostFood = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newPost: FoodPost = {
      id: Math.random().toString(36).substr(2, 9),
      donorId: 'donor_1',
      donorName: 'Green Cafe',
      foodType: formData.get('foodType') as string,
      quantity: formData.get('quantity') as string,
      location: formData.get('location') as string,
      status: 'available',
      createdAt: Date.now(),
    };
    setData((prev: any) => ({ ...prev, posts: [newPost, ...prev.posts] }));
    setShowPostModal(false);
  };

  const handleAcceptPost = (postId: string, estimatedMinutes: number) => {
    const post = data.posts.find((p: FoodPost) => p.id === postId);
    if (!post) return;

    const deadline = addMinutes(new Date(), estimatedMinutes).getTime();
    const newCollection: Collection = {
      id: Math.random().toString(36).substr(2, 9),
      postId,
      ngoId: 'ngo_1',
      ngoName: 'Helping Hands NGO',
      estimatedPickupTime: estimatedMinutes,
      pickupDeadline: deadline,
      status: 'pending',
      confirmedAt: Date.now(),
    };

    setData((prev: any) => ({
      ...prev,
      posts: prev.posts.map((p: FoodPost) => p.id === postId ? { ...p, status: 'accepted' } : p),
      collections: [...prev.collections, newCollection]
    }));

    addNotification(`NGO Helping Hands has confirmed collection. Estimated pickup time: ${estimatedMinutes} minutes.`);
    setShowAcceptModal(null);
  };

  const handleMarkCollected = (collectionId: string) => {
    const collection = data.collections.find((c: Collection) => c.id === collectionId);
    if (!collection) return;

    setData((prev: any) => ({
      ...prev,
      posts: prev.posts.map((p: FoodPost) => p.id === collection.postId ? { ...p, status: 'collected' } : p),
      collections: prev.collections.map((c: Collection) => c.id === collectionId ? { ...c, status: 'collected' } : c)
    }));
    addNotification(`Food successfully collected by ${collection.ngoName}.`);
  };

  // --- Views ---

  if (!role) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center p-6">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <h1 className="text-4xl font-serif font-bold text-stone-900 tracking-tight">Food Connect</h1>
            <p className="mt-2 text-stone-500 italic">Bridging the gap between surplus and need.</p>
          </div>
          <div className="grid grid-cols-1 gap-4">
            <button 
              onClick={() => setRole('donor')}
              className="group relative flex items-center justify-between p-6 bg-white border border-stone-200 rounded-2xl hover:border-emerald-500 hover:shadow-lg transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                  <User className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-stone-900">I am a Donor</h3>
                  <p className="text-sm text-stone-500">I have surplus food to share.</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-stone-300 group-hover:text-emerald-500" />
            </button>

            <button 
              onClick={() => setRole('ngo')}
              className="group relative flex items-center justify-between p-6 bg-white border border-stone-200 rounded-2xl hover:border-blue-500 hover:shadow-lg transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-blue-50 rounded-xl text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <Building2 className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-stone-900">I am an NGO</h3>
                  <p className="text-sm text-stone-500">I want to collect and distribute food.</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-stone-300 group-hover:text-blue-500" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 font-sans text-stone-900">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-bottom border-stone-200">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold">F</div>
            <h1 className="font-serif font-bold text-xl">Food Connect</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Bell className="w-5 h-5 text-stone-400" />
              {notifications.length > 0 && (
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full" />
              )}
            </div>
            <button 
              onClick={() => setRole(null)}
              className="p-2 hover:bg-stone-100 rounded-full text-stone-400"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold">Welcome back, {role === 'donor' ? 'Green Cafe' : 'Helping Hands'}</h2>
            <p className="text-stone-500">You are logged in as a <span className="capitalize font-semibold">{role}</span></p>
          </div>
          {role === 'donor' && (
            <button 
              onClick={() => setShowPostModal(true)}
              className="flex items-center gap-2 bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200"
            >
              <Plus className="w-5 h-5" />
              Post Food
            </button>
          )}
        </div>

        {/* Notifications Bar */}
        <AnimatePresence>
          {notifications.length > 0 && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-8 space-y-2"
            >
              {notifications.map((note, i) => (
                <div key={i} className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl flex items-start gap-3">
                  <Bell className="w-5 h-5 text-emerald-600 mt-0.5" />
                  <p className="text-emerald-800 text-sm">{note}</p>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-6">
            <h3 className="text-lg font-bold flex items-center gap-2">
              {role === 'donor' ? 'My Active Posts' : 'Available for Collection'}
            </h3>
            
            <div className="space-y-4">
              {data.posts
                .filter((p: FoodPost) => role === 'donor' ? p.donorId === 'donor_1' : p.status === 'available')
                .map((post: FoodPost) => (
                  <motion.div 
                    layout
                    key={post.id} 
                    className="bg-white border border-stone-200 p-6 rounded-2xl hover:shadow-md transition-shadow"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="text-xl font-bold text-stone-900">{post.foodType}</h4>
                        <p className="text-stone-500 text-sm">{post.quantity}</p>
                      </div>
                      <span className={cn(
                        "px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider",
                        post.status === 'available' ? "bg-emerald-100 text-emerald-700" :
                        post.status === 'accepted' ? "bg-blue-100 text-blue-700" :
                        "bg-stone-100 text-stone-500"
                      )}>
                        {post.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-stone-500 mb-6">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {post.location}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {formatDistanceToNow(post.createdAt)} ago
                      </div>
                    </div>
                    
                    {role === 'ngo' && post.status === 'available' && (
                      <button 
                        onClick={() => setShowAcceptModal(post)}
                        className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors"
                      >
                        Accept Collection
                      </button>
                    )}

                    {post.status === 'accepted' && (
                      <div className="mt-4 p-4 bg-blue-50 rounded-xl border border-blue-100">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 text-blue-700">
                            <Building2 className="w-4 h-4" />
                            <span className="font-bold">Accepted by NGO</span>
                          </div>
                          {data.collections.find((c: Collection) => c.postId === post.id) && (
                            <CountdownTimer 
                              deadline={data.collections.find((c: Collection) => c.postId === post.id)!.pickupDeadline} 
                              onExpire={() => addNotification(`Alert: Pickup deadline missed for ${post.foodType}.`)}
                            />
                          )}
                        </div>
                      </div>
                    )}
                  </motion.div>
                ))}
            </div>
          </div>

          {/* Sidebar / Tracking */}
          <div className="space-y-6">
            <h3 className="text-lg font-bold">Active Trackings</h3>
            <div className="space-y-4">
              {data.collections
                .filter((c: Collection) => role === 'donor' ? true : c.ngoId === 'ngo_1')
                .filter((c: Collection) => c.status === 'pending')
                .map((col: Collection) => {
                  const post = data.posts.find((p: FoodPost) => p.id === col.postId);
                  return (
                    <div key={col.id} className="bg-white border border-stone-200 p-5 rounded-2xl shadow-sm">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 bg-stone-100 rounded-full flex items-center justify-center">
                          <Clock className="w-5 h-5 text-stone-400" />
                        </div>
                        <div>
                          <h5 className="font-bold text-sm">{post?.foodType}</h5>
                          <p className="text-xs text-stone-500">Pickup Deadline</p>
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <CountdownTimer 
                          deadline={col.pickupDeadline} 
                          onExpire={() => addNotification(`Deadline expired for ${post?.foodType}!`)}
                        />
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-stone-500">NGO</span>
                          <span className="font-bold">{col.ngoName}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-stone-500">Est. Time</span>
                          <span className="font-bold">{col.estimatedPickupTime} mins</span>
                        </div>
                      </div>

                      {role === 'ngo' && (
                        <button 
                          onClick={() => handleMarkCollected(col.id)}
                          className="w-full mt-4 flex items-center justify-center gap-2 bg-emerald-50 text-emerald-700 py-2 rounded-lg font-bold hover:bg-emerald-100 transition-colors"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          Mark Collected
                        </button>
                      )}
                    </div>
                  );
                })}
              
              {data.collections.filter((c: Collection) => c.status === 'pending').length === 0 && (
                <div className="text-center py-12 bg-stone-100/50 rounded-2xl border border-dashed border-stone-200">
                  <AlertCircle className="w-8 h-8 text-stone-300 mx-auto mb-2" />
                  <p className="text-stone-400 text-sm">No active collections</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Post Modal */}
      <AnimatePresence>
        {showPostModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPostModal(false)}
              className="absolute inset-0 bg-stone-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white w-full max-w-lg rounded-3xl shadow-2xl p-8"
            >
              <h3 className="text-2xl font-bold mb-6">Post Food Availability</h3>
              <form onSubmit={handlePostFood} className="space-y-4">
                <div>
                  <label className="block text-sm font-bold mb-1">Food Type</label>
                  <input name="foodType" required placeholder="e.g. Fresh Sandwiches" className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-bold mb-1">Quantity</label>
                  <input name="quantity" required placeholder="e.g. 20 portions" className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-bold mb-1">Location</label>
                  <input name="location" required placeholder="e.g. 123 Main St, Downtown" className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" />
                </div>
                <div className="pt-4 flex gap-3">
                  <button type="button" onClick={() => setShowPostModal(false)} className="flex-1 px-6 py-3 border border-stone-200 rounded-xl font-bold hover:bg-stone-50">Cancel</button>
                  <button type="submit" className="flex-1 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700">Post Now</button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Accept Modal */}
      <AnimatePresence>
        {showAcceptModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAcceptModal(null)}
              className="absolute inset-0 bg-stone-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-3xl shadow-2xl p-8"
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold">Confirm Collection</h3>
                <p className="text-stone-500">Please provide an estimated pickup time for <span className="font-bold text-stone-900">{showAcceptModal.foodType}</span>.</p>
              </div>
              
              <div className="grid grid-cols-2 gap-3 mb-8">
                {[15, 30, 45, 60].map(mins => (
                  <button 
                    key={mins}
                    onClick={() => handleAcceptPost(showAcceptModal.id, mins)}
                    className="p-4 border border-stone-200 rounded-2xl hover:border-blue-500 hover:bg-blue-50 transition-all text-center group"
                  >
                    <span className="block text-xl font-bold group-hover:text-blue-600">{mins}</span>
                    <span className="text-xs text-stone-500 uppercase font-bold tracking-wider">Minutes</span>
                  </button>
                ))}
              </div>

              <button 
                onClick={() => setShowAcceptModal(null)}
                className="w-full py-3 text-stone-400 font-bold hover:text-stone-600"
              >
                Cancel
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
